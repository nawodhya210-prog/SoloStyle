
function setupEventListeners() {
    document.getElementById('searchBtn').addEventListener('click', performSearch);
    document.getElementById('searchInput').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') performSearch();
    });
    document.getElementById('cartIconBtn').addEventListener('click', () => {
        displayCart();
        document.getElementById('cartModal').style.display = 'block';
    });
    document.querySelector('.close').addEventListener('click', closeCart);
    document.getElementById('contactForm').addEventListener('submit', handleContactSubmit);
    window.addEventListener('click', (e) => {
        if (e.target.id === 'cartModal') closeCart();
    });
}

function performSearch() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const filtered = products.filter(p =>
        p.name.toLowerCase().includes(searchTerm) ||
        p.description.toLowerCase().includes(searchTerm)
    );
    renderProducts(filtered.length > 0 ? filtered : []);
}

function filterProducts(category) {
    document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');

    filteredProducts = category === 'all' ? products : products.filter(p => p.category === category);
    renderProducts(filteredProducts);
}

function sortProducts(sort) {
    let sorted = [...filteredProducts];
    if (sort === 'price-low') {
        sorted.sort((a, b) => a.price - b.price);
    }
    renderProducts(sorted);
}

function renderProducts(productsToDisplay) {
    const productGrid = document.getElementById('productGrid');
    productGrid.innerHTML = '';

    if (productsToDisplay.length === 0) {
        productGrid.innerHTML = '<div class="no-products"><p>No products found</p></div>';
        return;
    }

    productsToDisplay.forEach((product, index) => {
        const isInWishlist = wishlist.some(item => item.id === product.id);
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        productCard.style.animationDelay = `${index * 0.1}s`;
        productCard.innerHTML = `
            <div class="product-image">
                <img src="${product.image}" alt="${product.name} - ${product.description}" tabindex="0" aria-label="${product.name} product image" loading="lazy">
                <div class="product-badge">${product.category === 'shoes' ? '👟' : '🧦'}</div>
                <button class="wishlist-btn" onclick="toggleWishlist(${product.id})" title="Add to wishlist" aria-label="Add ${product.name} to wishlist">
                    <i class="fas fa-heart" style="color: ${isInWishlist ? '#ff6b6b' : '#ccc'}; font-size: 1.5rem;"></i>
                </button>
            </div>
            <div class="product-info">
                <h3>${product.name}</h3>
                <p class="description">${product.description}</p>
                <div class="product-rating">
                    <span class="stars">${'⭐'.repeat(product.rating)}</span>
                    <span class="reviews">(${product.reviews} reviews)</span>
                </div>
                <p class="price">LKR ${product.price.toLocaleString()}</p>
                <button onclick="addToCart(${product.id})" class="btn btn-primary btn-full" aria-label="Add ${product.name} to cart">
                    <i class="fas fa-shopping-bag"></i> Add to Cart
                </button>
            </div>
        `;
        productGrid.appendChild(productCard);
    });
}

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({ ...product, quantity: 1 });
    }

    saveCartToStorage();
    updateCounts();
    showNotification(`✅ ${product.name} added to cart!`);
}

function toggleWishlist(productId) {
    const product = products.find(p => p.id === productId);
    const index = wishlist.findIndex(item => item.id === productId);

    if (index > -1) {
        wishlist.splice(index, 1);
        showNotification(`❤️ Removed from wishlist`);
    } else {
        wishlist.push(product);
        showNotification(`❤️ Added to wishlist`);
    }

    saveWishlistToStorage();
    updateCounts();
    renderProducts(filteredProducts);
}

function displayCart() {
    const cartItems = document.getElementById('cartItems');
    if (cart.length === 0) {
        cartItems.innerHTML = '<p class="empty-cart">Your cart is empty</p>';
        document.getElementById('cartTotal').textContent = '0.00';
        return;
    }

    cartItems.innerHTML = cart.map(item => `
        <div class="cart-item">
            <img src="${item.image}" alt="${item.name}">
            <div class="cart-item-info">
                <h4>${item.name}</h4>
                <p>LKR ${item.price.toLocaleString()}</p>
            </div>
            <div class="cart-item-controls">
                <input type="number" value="${item.quantity}" min="1" onchange="updateQuantity(${item.id}, this.value)">
                <p>LKR ${(item.price * item.quantity).toLocaleString()}</p>
                <button onclick="removeFromCart(${item.id})" class="btn btn-danger">Remove</button>
            </div>
        </div>
    `).join('');

    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    document.getElementById('cartTotal').textContent = total.toLocaleString();
}

function updateQuantity(productId, quantity) {
    const item = cart.find(p => p.id === productId);
    if (item) {
        item.quantity = parseInt(quantity);
        if (item.quantity <= 0) removeFromCart(productId);
        else {
            saveCartToStorage();
            updateCounts();
            displayCart();
        }
    }
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    saveCartToStorage();
    updateCounts();
    displayCart();
}

function checkout() {
    if (cart.length === 0) {
        alert('Your cart is empty!');
        return;
    }
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    alert(`✅ Order Confirmed!\nTotal: LKR ${total.toLocaleString()}\n\nWe'll contact you soon at your registered number.\n\nThank you for shopping at SoleStyle!`);
    cart = [];
    saveCartToStorage();
    updateCounts();
    closeCart();
}

function closeCart() {
    document.getElementById('cartModal').style.display = 'none';
}

function updateCounts() {
    document.querySelector('.cart-count').textContent = cart.reduce((total, item) => total + item.quantity, 0);
    document.querySelector('.wishlist-count').textContent = wishlist.length;
}

function handleContactSubmit(e) {
    e.preventDefault();
    showNotification('✅ Message sent successfully! We\'ll get back to you soon.');
    e.target.reset();
}

function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
}

function saveCartToStorage() {
    localStorage.setItem('soleStyleCart', JSON.stringify(cart));
}

function loadCartFromStorage() {
    const saved = localStorage.getItem('soleStyleCart');
    if (saved) cart = JSON.parse(saved);
}

function saveWishlistToStorage() {
    localStorage.setItem('soleStyleWishlist', JSON.stringify(wishlist));
}

function loadWishlistFromStorage() {
    const saved = localStorage.getItem('soleStyleWishlist');
    if (saved) wishlist = JSON.parse(saved);
}

function animateOnScroll() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
            }
        });
    });
    document.querySelectorAll('.product-card, .testimonial-card, .offer-item').forEach(el => observer.observe(el));
}

/**
 * SoleStyle E-Commerce Store
 * Main JavaScript File
 */

// ============================================
// 1. PRODUCT DATABASE
// ============================================

const products = [
    {
        id: 1,
        name: "Ultra Run Pro",
        price: 5999,
        image: "images/Gent's-Shoes(2).jpg",
        category: "shoes",
        description: "Professional running shoes with advanced cushioning technology",
        rating: 5,
        reviews: 120,
        featured: true
    },
    {
        id: 2,
        name: "Casual Comfort",
        price: 4499,
        image: "images/Gent's-Shoes(2).jpg",
        category: "shoes",
        description: "Perfect everyday casual shoes for comfort and style",
        rating: 5,
        reviews: 95,
        featured: true
    },
    {
        id: 3,
        name: "Premium Socks Set",
        price: 1999,
        image: "images/Gent's-Shoes(3).jpg",
        category: "socks",
        description: "Pack of 3 premium quality socks for everyday wear",
        rating: 5,
        reviews: 200,
        featured: false
    },
    {
        id: 4,
        name: "Sports Elite",
        price: 6999,
        image: "images/Gent's-Shoes.jpg",
        category: "shoes",
        description: "Professional sports shoes designed for athletes",
        rating: 5,
        reviews: 150,
        featured: true
    },
    {
        id: 5,
        name: "Comfort Ankle Socks",
        price: 2499,
        image: "images/ankle-socks.jpg",
        category: "socks",
        description: "Breathable ankle socks with moisture-wicking technology",
        rating: 5,
        reviews: 180,
        featured: false
    },
    {
        id: 6,
        name: "Formal Elegance",
        price: 7500,
        image: "images/Gent's-Shoes.jpg",
        category: "shoes",
        description: "Elegant formal shoes for professional occasions",
        rating: 5,
        reviews: 110,
        featured: true
    },
    {
        id: 7,
        name: "Low Cut Socks",
        price: 1599,
        image: "images/Gent's-Shoes.jpg",
        category: "socks",
        description: "Lightweight low-cut socks ideal for sneakers",
        rating: 5,
        reviews: 160,
        featured: false
    },
    {
        id: 8,
        name: "Urban Sneaker",
        price: 5299,
        image: "images/Gent's-Shoes(2).jpg",
        category: "shoes",
        description: "Modern urban sneakers for style-conscious individuals",
        rating: 5,
        reviews: 175,
        featured: true
    }
];

// ============================================
// 2. STATE MANAGEMENT
// ============================================

let cart = [];
let wishlist = [];
let currentFilter = 'all';
let filteredProducts = products;

// ============================================
// 3. INITIALIZATION
// ============================================

document.addEventListener("DOMContentLoaded", () => {
    console.log("🔥 SoleStyle Store Initialized");
    
    // Load saved data
    loadCartFromStorage();
    loadWishlistFromStorage();
    
    // Render initial content
    renderProducts(products);
    updateCounts();
    
    // Setup event listeners
    setupEventListeners();
    
    // Setup animations
    setupScrollAnimations();
});

// ============================================
// 4. EVENT LISTENERS SETUP
// ============================================

function setupEventListeners() {
    // Search functionality
    const searchForm = document.querySelector('.search-form');
    searchForm.addEventListener('submit', handleSearchSubmit);

    // Cart actions
    document.getElementById('cartBtn').addEventListener('click', () => {
        displayCart();
        document.getElementById('cartModal').style.display = 'flex';
    });

    document.getElementById('closeCartBtn').addEventListener('click', closeCart);

    // Close modal when clicking outside
    document.getElementById('cartModal').addEventListener('click', (e) => {
        if (e.target.id === 'cartModal') closeCart();
    });

    // Contact form
    document.getElementById('contactForm').addEventListener('submit', handleContactSubmit);

    // Newsletter form
    document.querySelector('.newsletter-form').addEventListener('submit', handleNewsletterSubmit);

    // Mobile menu
    document.getElementById('mobileMenuBtn').addEventListener('click', toggleMobileMenu);
}

// ============================================
// 5. SEARCH FUNCTIONALITY
// ============================================

function handleSearchSubmit(e) {
    e.preventDefault();
    const searchTerm = document.getElementById('searchInput').value.toLowerCase().trim();
    
    if (!searchTerm) {
        renderProducts(products);
        return;
    }

    const filtered = products.filter(product =>
        product.name.toLowerCase().includes(searchTerm) ||
        product.description.toLowerCase().includes(searchTerm) ||
        product.category.toLowerCase().includes(searchTerm)
    );

    renderProducts(filtered);
    document.getElementById('searchInput').value = '';
    
    showNotification(`Found ${filtered.length} product${filtered.length !== 1 ? 's' : ''}`);
}

// ============================================
// 6. PRODUCT FILTERING
// ============================================

function filterProducts(category) {
    // Update active filter button
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');

    currentFilter = category;

    if (category === 'all') {
        filteredProducts = products;
    } else {
        filteredProducts = products.filter(p => p.category === category);
    }

    renderProducts(filteredProducts);
    
    // Smooth scroll to products
    document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
}

// ============================================
// 7. PRODUCT SORTING
// ============================================

function sortProducts(sortType) {
    let sorted = [...filteredProducts];

    switch (sortType) {
        case 'price-low':
            sorted.sort((a, b) => a.price - b.price);
            break;
        case 'price-high':
            sorted.sort((a, b) => b.price - a.price);
            break;
        case 'newest':
            sorted.sort((a, b) => b.id - a.id);
            break;
        default:
            sorted = filteredProducts;
    }

    renderProducts(sorted);
}

// ============================================
// 8. PRODUCT RENDERING
// ============================================

function renderProducts(productsToDisplay) {
    const heroGradient = products.filter(p => p.featured);
    const productGrid = document.getElementById('productGrid');
    const noResults = document.getElementById('noResults');

    productGrid.innerHTML = '';

    // Show/hide no results message
    if (productsToDisplay.length === 0) {
        noResults.style.display = 'flex';
        return;
    } else {
        noResults.style.display = 'none';
    }

    productsToDisplay.forEach((product, index) => {
        const isInWishlist = wishlist.some(item => item.id === product.id);
        
        const productCard = document.createElement('article');
        productCard.className = 'product-card';
        productCard.style.animationDelay = `${index * 0.1}s`;

        productCard.innerHTML = `
            <div class="product-image-wrapper">
                <img 
                    src="${product.image}" 
                    alt="${product.name}" 
                    class="product-image"
                    loading="lazy"
                >
                <span class="product-badge">${product.category === 'shoes' ? '👟' : '🧦'}</span>
                
                <button 
                    class="wishlist-btn ${isInWishlist ? 'in-wishlist' : ''}" 
                    onclick="toggleWishlist(${product.id})" 
                    aria-label="Add to wishlist"
                    title="${isInWishlist ? 'Remove from wishlist' : 'Add to wishlist'}"
                >
                    <i class="fas fa-heart"></i>
                </button>
            </div>

            <div class="product-details">
                <h3 class="product-name">${product.name}</h3>
                <p class="product-description">${product.description}</p>
                
                <div class="product-rating">
                    <span class="stars">${'⭐'.repeat(product.rating)}</span>
                    <span class="reviews">
                        (${product.reviews} review${product.reviews !== 1 ? 's' : ''})
                    </span>
                </div>

                <p class="product-price">LKR ${formatPrice(product.price)}</p>

                <button 
                    onclick="addToCart(${product.id})" 
                    class="btn btn-primary btn-full add-cart-btn"
                    aria-label="Add ${product.name} to cart"
                >
                    <i class="fas fa-shopping-bag"></i> Add to Cart
                </button>
            </div>
        `;

        productGrid.appendChild(productCard);
    });

    // Trigger animations
    setTimeout(() => {
        document.querySelectorAll('.product-card').forEach(card => {
            card.classList.add('animate');
        });
    }, 100);
}

// ============================================
// 9. CART MANAGEMENT
// ============================================

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) {
        showNotification('❌ Product not found', 'error');
        return;
    }

    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity++;
        showNotification(`✅ ${product.name} quantity updated`);
    } else {
        cart.push({ ...product, quantity: 1 });
        showNotification(`✅ ${product.name} added to cart`);
    }

    saveCartToStorage();
    updateCounts();
}

function displayCart() {
    const cartItems = document.getElementById('cartItems');
    
    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <h3>Your cart is empty</h3>
                <p>Start shopping to add items to your cart</p>
                <button class="btn btn-primary" onclick="closeCart()">Continue Shopping</button>
            </div>
        `;
        document.getElementById('cartTotal').textContent = 'LKR 0.00';
        document.getElementById('subtotal').textContent = 'LKR 0.00';
        return;
    }

    cartItems.innerHTML = cart.map(item => `
        <div class="cart-item">
            <img 
                src="${item.image}" 
                alt="${item.name}" 
                class="cart-item-image"
            >
            <div class="cart-item-info">
                <h4>${item.name}</h4>
                <p class="cart-item-price">LKR ${formatPrice(item.price)}</p>
            </div>
            <div class="cart-item-controls">
                <button 
                    onclick="updateQuantity(${item.id}, ${item.quantity - 1})"
                    class="qty-btn"
                    aria-label="Decrease quantity"
                >
                    <i class="fas fa-minus"></i>
                </button>
                <input 
                    type="number" 
                    value="${item.quantity}" 
                    min="1" 
                    onchange="updateQuantity(${item.id}, this.value)"
                    class="qty-input"
                    aria-label="Quantity"
                >
                <button 
                    onclick="updateQuantity(${item.id}, ${item.quantity + 1})"
                    class="qty-btn"
                    aria-label="Increase quantity"
                >
                    <i class="fas fa-plus"></i>
                </button>
            </div>
            <p class="cart-item-total">LKR ${formatPrice(item.price * item.quantity)}</p>
            <button 
                onclick="removeFromCart(${item.id})"
                class="btn btn-danger btn-sm"
                aria-label="Remove from cart"
            >
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `).join('');

    calculateCartTotals();
}

function updateQuantity(productId, quantity) {
    quantity = parseInt(quantity);
    
    if (quantity < 1) {
        removeFromCart(productId);
        return;
    }

    const item = cart.find(p => p.id === productId);
    if (item) {
        item.quantity = quantity;
        saveCartToStorage();
        updateCounts();
        displayCart();
    }
}

function removeFromCart(productId) {
    const product = cart.find(p => p.id === productId);
    cart = cart.filter(item => item.id !== productId);
    
    saveCartToStorage();
    updateCounts();
    displayCart();
    
    showNotification(`${product.name} removed from cart`);
}

function calculateCartTotals() {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const shipping = subtotal >= 5000 ? 0 : 500;
    const total = subtotal + shipping;

    document.getElementById('subtotal').textContent = `LKR ${formatPrice(subtotal)}`;
    document.getElementById('shipping').textContent = shipping === 0 ? 'Free' : `LKR ${formatPrice(shipping)}`;
    document.getElementById('cartTotal').textContent = `LKR ${formatPrice(total)}`;
}

function proceedCheckout() {
    if (cart.length === 0) {
        showNotification('Your cart is empty', 'error');
        return;
    }

    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const cartSummary = cart.map(item => `${item.name} x${item.quantity}`).join(', ');

    alert(
        `✅ Thank you for your order!\n\n` +
        `Items: ${cartSummary}\n\n` +
        `Total: LKR ${formatPrice(total)}\n\n` +
        `We will contact you soon at your registered number to confirm delivery.\n\n` +
        `Thank you for shopping at SoleStyle! 🎉`
    );

    cart = [];
    saveCartToStorage();
    updateCounts();
    closeCart();
    showNotification('Order confirmed! We will contact you soon.');
}

function closeCart() {
    document.getElementById('cartModal').style.display = 'none';
}

// ============================================
// 10. WISHLIST MANAGEMENT
// ============================================

function toggleWishlist(productId) {
    const product = products.find(p => p.id === productId);
    const index = wishlist.findIndex(item => item.id === productId);

    if (index > -1) {
        wishlist.splice(index, 1);
        showNotification(`❤️ Removed from wishlist`);
    } else {
        wishlist.push(product);
        showNotification(`❤️ Added to wishlist`);
    }

    saveWishlistToStorage();
    updateCounts();
    
    // Re-render current products to update wishlist button states
    renderProducts(filteredProducts);
}

// ============================================
// 11. CONTACT & NEWSLETTER FORMS
// ============================================

function handleContactSubmit(e) {
    e.preventDefault();
    
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();

    if (!name || !email || !message) {
        showNotification('Please fill in all fields', 'error');
        return;
    }

    // Simulate form submission
    console.log('Contact Message:', { name, email, message });
    
    showNotification('✅ Thank you! We received your message and will get back to you soon.');
    e.target.reset();
}

function handleNewsletterSubmit(e) {
    e.preventDefault();
    
    const email = e.target.querySelector('input[type="email"]').value.trim();
    
    if (!email) {
        showNotification('Please enter a valid email', 'error');
        return;
    }

    console.log('Newsletter Signup:', email);
    
    showNotification('✅ Successfully subscribed to our newsletter!');
    e.target.reset();
}

// ============================================
// 12. UTILITY FUNCTIONS
// ============================================

function formatPrice(price) {
    return price.toLocaleString('en-LK');
}

function updateCounts() {
    const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
    document.querySelector('.cart-count').textContent = cartCount;
    document.querySelector('.wishlist-count').textContent = wishlist.length;
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            ${message}
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

function resetFilters() {
    currentFilter = 'all';
    document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelector('[data-filter="all"]').classList.add('active');
    renderProducts(products);
}

function toggleMobileMenu() {
    const menu = document.querySelector('.navbar-menu');
    menu.classList.toggle('active');
}

// ============================================
// 13. LOCAL STORAGE
// ============================================

function saveCartToStorage() {
    localStorage.setItem('soleStyleCart', JSON.stringify(cart));
}

function loadCartFromStorage() {
    const saved = localStorage.getItem('soleStyleCart');
    if (saved) {
        cart = JSON.parse(saved);
    }
}

function saveWishlistToStorage() {
    localStorage.setItem('soleStyleWishlist', JSON.stringify(wishlist));
}

function loadWishlistFromStorage() {
    const saved = localStorage.getItem('soleStyleWishlist');
    if (saved) {
        wishlist = JSON.parse(saved);
    }
}

// ============================================
// 14. SCROLL ANIMATIONS
// ============================================

function setupScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    document.querySelectorAll('.offer-card, .testimonial-card, .product-card').forEach(el => {
        observer.observe(el);
    });
}

// ============================================
// 15. CATEGORY & NAVIGATION HELPERS
// ============================================

/**
 * Count products by category
 */
function getProductCountByCategory(category) {
    return products.filter(p => p.category === category).length;
}

/**
 * Smooth scroll to products section
 */
function scrollToProducts() {
    setTimeout(() => {
        const productsSection = document.getElementById('products');
        productsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 300);
}

/**
 * Get featured products by category
 */
function getFeaturedProducts(category) {
    return products.filter(p => p.category === category && p.featured);
}

/**
 * Update category counts dynamically
 */
function updateCategoryCounts() {
    const shoeCount = getProductCountByCategory('shoes');
    const sockCount = getProductCountByCategory('socks');
    
    const shoeCard = document.querySelector('.shoes-card .category-count span');
    const sockCard = document.querySelector('.socks-card .category-count span');
    
    if (shoeCard) shoeCard.textContent = `${shoeCount}+ Products`;
    if (sockCard) sockCard.textContent = `${sockCount}+ Products`;
}

/**
 * Initialize categories section
 */
function initCategories() {
    updateCategoryCounts();
    setupCategoryHovers();
}

/**
 * Setup category card hover effects
 */
function setupCategoryHovers() {
    const cards = document.querySelectorAll('.category-card');
    
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.classList.add('hovered');
        });
        
        card.addEventListener('mouseleave', function() {
            this.classList.remove('hovered');
        });
    });
}

// Update the DOMContentLoaded event listener
document.addEventListener("DOMContentLoaded", () => {
    console.log("🔥 SoleStyle Store Initialized");
    
    // Load saved data
    loadCartFromStorage();
    loadWishlistFromStorage();
    
    // Render initial content
    renderProducts(products);
    updateCounts();
    
    // Initialize categories
    initCategories();
    
    // Setup event listeners
    setupEventListeners();
    
    // Setup animations
    setupScrollAnimations();
});


/**
 * Quick view featured products by category
 */
function showCategoryQuickView(category) {
    const featured = getFeaturedProducts(category);
    const categoryName = category === 'shoes' ? 'Premium Shoes' : 'Premium Socks';
    
    console.log(`Showing featured ${categoryName}:`, featured);
    
    // Filter and display products
    filterProducts(category);
    scrollToProducts();
    
    // Show notification
    showNotification(`🎯 Showing all ${categoryName} (${featured.length} featured items)`);
}

/**
 * Get category details
 */
function getCategoryDetails(category) {
    const details = {
        shoes: {
            name: '👟 Shoes',
            description: 'Premium footwear for every occasion',
            count: getProductCountByCategory('shoes'),
            color: '#667eea'
        },
        socks: {
            name: '🧦 Socks',
            description: 'Comfortable and durable socks',
            count: getProductCountByCategory('socks'),
            color: '#ff6b6b'
        }
    };
    return details[category] || null;
}

/**
 * Display category details on click
 */
function showCategoryDetails(category) {
    const details = getCategoryDetails(category);
    if (details) {
        console.log(`Category: ${details.name}`, details);
        showNotification(`📦 ${details.name} - ${details.count} products available`);
    }
}


/**
 * Get product statistics
 */
function getProductStats() {
    const stats = {
        total: products.length,
        shoes: products.filter(p => p.category === 'shoes').length,
        socks: products.filter(p => p.category === 'socks').length,
        featured: products.filter(p => p.featured).length,
        avgPrice: Math.round(products.reduce((sum, p) => sum + p.price, 0) / products.length)
    };
    return stats;
}

/**
 * Log product statistics (for debugging)
 */
function logProductStats() {
    const stats = getProductStats();
    console.log('📊 Product Statistics:', stats);
    console.log(`Total Products: ${stats.total}`);
    console.log(`Shoes: ${stats.shoes}`);
    console.log(`Socks: ${stats.socks}`);
    console.log(`Featured: ${stats.featured}`);
    console.log(`Average Price: LKR ${formatPrice(stats.avgPrice)}`);
}

// Call this on initialization
document.addEventListener("DOMContentLoaded", () => {
    console.log("🔥 SoleStyle Store Initialized");
    
    // Load saved data
    loadCartFromStorage();
    loadWishlistFromStorage();
    
    // Render initial content
    renderProducts(products);
    updateCounts();
    
    // Initialize categories
    initCategories();
    
    // Setup event listeners
    setupEventListeners();
    
    // Setup animations
    setupScrollAnimations();
    
    // Log product stats
    logProductStats();
});

/**
 * SoleStyle Share & Subscription System
 */

// ============================================
// 1. INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    console.log('🔥 SoleStyle Share Page Loaded');
    
    // Set store link
    setStoreLink();
    
    // Setup form handlers
    setupFormHandlers();
    
    // Load stored subscriptions
    loadStoredSubscriptions();
    
    // Track page visit
    trackPageVisit();
});

// ============================================
// 2. STORE LINK MANAGEMENT
// ============================================

/**
 * Get the base store URL
 */
function getStoreURL() {
    // Replace with your actual domain
    return window.location.origin + '/index.html';
    // For development: return 'http://localhost/shoe-store/index.html';
    // For production: return 'https://solestyle.store';
}

/**
 * Get referral link with tracking
 */
function getReferralLink() {
    const baseURL = getStoreURL();
    const referrerId = generateReferralId();
    return `${baseURL}?ref=${referrerId}`;
}

/**
 * Generate unique referral ID
 */
function generateReferralId() {
    // In production, generate unique ID for each referrer
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 8);
    return `${timestamp}${random}`;
}

/**
 * Set store link in input field
 */
function setStoreLink() {
    const linkInput = document.getElementById('storeLink');
    if (linkInput) {
        linkInput.value = getStoreURL();
    }
}

/**
 * Copy store link to clipboard
 */
function copyStoreLink() {
    const linkInput = document.getElementById('storeLink');
    
    if (!linkInput) {
        showNotification('❌ Link not found', 'error');
        return;
    }

    // Copy to clipboard
    navigator.clipboard.writeText(linkInput.value).then(() => {
        showNotification('✅ Link copied to clipboard!', 'success');
        
        // Change button text temporarily
        const copyBtn = event.target.closest('button') || document.querySelector('.copy-link-btn');
        if (copyBtn) {
            const originalHTML = copyBtn.innerHTML;
            copyBtn.innerHTML = '<i class="fas fa-check"></i>';
            setTimeout(() => {
                copyBtn.innerHTML = originalHTML;
            }, 2000);
        }
    }).catch(err => {
        console.error('Copy failed:', err);
        showNotification('❌ Failed to copy link', 'error');
    });
}

// ============================================
// 3. SUBSCRIPTION HANDLING
// ============================================

/**
 * Handle subscription form submission
 */
function handleSubscription(e) {
    e.preventDefault();
    
    const form = e.target;
    const name = document.getElementById('subName').value.trim();
    const email = document.getElementById('subEmail').value.trim();
    const phone = document.getElementById('subPhone').value.trim();
    const termsCheck = document.getElementById('termsCheck').checked;

    // Validation
    if (!name || !email || !phone) {
        showNotification('❌ Please fill in all fields', 'error');
        return;
    }

    if (!validateEmail(email)) {
        showNotification('❌ Please enter a valid email', 'error');
        return;
    }

    if (!validatePhone(phone)) {
        showNotification('❌ Please enter a valid phone number', 'error');
        return;
    }

    if (!termsCheck) {
        showNotification('❌ Please agree to the terms', 'error');
        return;
    }

    // Create subscription object
    const subscription = {
        id: generateSubscriptionId(),
        name: name,
        email: email,
        phone: phone,
        subscribedDate: new Date().toLocaleString(),
        discountCode: generateDiscountCode(),
        referralLink: getStoreURL() + `?ref=${name.toLowerCase().replace(/\s/g, '')}`
    };

    // Save subscription
    saveSubscription(subscription);
    
    // Show success message
    showSubscriptionSuccess(subscription);
    
    // Send confirmation (in production, would send email/SMS)
    sendSubscriptionConfirmation(subscription);
    
    // Reset form
    form.reset();
}

/**
 * Generate unique subscription ID
 */
function generateSubscriptionId() {
    return `SUB-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Generate 10% discount code
 */
function generateDiscountCode() {
    const codes = ['WELCOME10', 'SOLESTYLE10', 'FRIEND10', 'SAVE10', 'ENJOY10'];
    const randomCode = codes[Math.floor(Math.random() * codes.length)];
    return `${randomCode}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`;
}

/**
 * Validate email
 */
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

/**
 * Validate phone number (Sri Lankan format)
 */
function validatePhone(phone) {
    // Accept formats: 0714356043, 94704356043, +94704356043, +94 70 435 6043
    const re = /^(\+?94|0)[0-9]{9,10}$/;
    return re.test(phone.replace(/\s/g, ''));
}

/**
 * Save subscription to localStorage
 */
function saveSubscription(subscription) {
    let subscriptions = JSON.parse(localStorage.getItem('soleStyleSubscriptions')) || [];
    subscriptions.push(subscription);
    localStorage.setItem('soleStyleSubscriptions', JSON.stringify(subscriptions));
    console.log('✅ Subscription saved:', subscription);
}

/**
 * Load stored subscriptions
 */
function loadStoredSubscriptions() {
    const subscriptions = JSON.parse(localStorage.getItem('soleStyleSubscriptions')) || [];
    console.log(`📊 Total Subscriptions: ${subscriptions.length}`);
    return subscriptions;
}

/**
 * Show subscription success message
 */
function showSubscriptionSuccess(subscription) {
    const form = document.getElementById('subscriptionForm');
    const successDiv = document.getElementById('subscriptionSuccess');
    const successMessage = document.getElementById('successMessage');

    if (form && successDiv) {
        form.style.display = 'none';
        successDiv.style.display = 'block';
        
        successMessage.innerHTML = `
            <p>✅ Welcome <strong>${subscription.name}</strong>!</p>
            <p>Your discount code: <strong style="color: var(--accent);">${subscription.discountCode}</strong></p>
            <p style="font-size: 0.9rem; margin-top: 1rem;">Use this code at checkout to get 10% OFF your first purchase!</p>
        `;

        // Copy discount code to clipboard after 1 second
        setTimeout(() => {
            navigator.clipboard.writeText(subscription.discountCode);
        }, 1000);
    }
}

/**
 * Send subscription confirmation (Mock - In production would use email service)
 */
function sendSubscriptionConfirmation(subscription) {
    const message = `
    🎉 Welcome to SoleStyle!
    
    Name: ${subscription.name}
    Email: ${subscription.email}
    Phone: ${subscription.phone}
    
    Your 10% Discount Code: ${subscription.discountCode}
    
    Next Steps:
    1. Visit our store: ${getStoreURL()}
    2. Use code "${subscription.discountCode}" at checkout
    3. Get 10% OFF your first purchase!
    
    Share with friends: ${subscription.referralLink}
    
    Questions? Contact us on WhatsApp: +94 70 435 6043
    `;

    console.log('📧 Confirmation Message Ready:', message);
    
    // In production, send via email service
    // In production, send via WhatsApp API
}

// ============================================
// 4. SOCIAL SHARING FUNCTIONS
// ============================================

/**
 * Share on WhatsApp
 */
function shareOnWhatsApp() {
    const storeLink = getStoreURL();
    const message = encodeURIComponent(
        `🔥 Check out SoleStyle - Premium Shoes & Socks!\n\n` +
        `👟 Premium Quality\n` +
        `✨ Best Prices\n` +
        `🚚 Free Shipping on Orders Over LKR 5000\n` +
        `⭐ 5.0 Star Rating\n\n` +
        `Visit us: ${storeLink}\n\n` +
        `Don't miss out! 🎉`
    );
    
    window.open(`https://wa.me/?text=${message}`, '_blank');
}

/**
 * Share on Facebook
 */
function shareOnFacebook() {
    const storeLink = getStoreURL();
    window.open(
        `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(storeLink)}`,
        '_blank'
    );
}

/**
 * Share on Twitter
 */
function shareOnTwitter() {
    const storeLink = getStoreURL();
    const text = encodeURIComponent(
        '🔥 Check out SoleStyle - Premium Shoes & Socks in Sri Lanka! ' +
        'Free shipping on orders over LKR 5000. ⭐5.0 rated! ' +
        storeLink
    );
    
    window.open(
        `https://twitter.com/intent/tweet?text=${text}`,
        '_blank'
    );
}

// ============================================
// 5. FAQ FUNCTIONALITY
// ============================================

/**
 * Toggle FAQ answer
 */
function toggleFAQ(button) {
    const faqItem = button.parentElement;
    const answer = faqItem.querySelector('.faq-answer');
    const isOpen = faqItem.classList.contains('active');

    // Close all other FAQ items
    document.querySelectorAll('.faq-item').forEach(item => {
        if (item !== faqItem) {
            item.classList.remove('active');
        }
    });

    // Toggle current item
    faqItem.classList.toggle('active');
    
    if (!isOpen) {
        answer.style.maxHeight = answer.scrollHeight + 'px';
    } else {
        answer.style.maxHeight = '0px';
    }
}

// ============================================
// 6. NOTIFICATIONS
// ============================================

/**
 * Show notification
 */
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `share-notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            ${message}
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Trigger animation
    setTimeout(() => notification.classList.add('show'), 10);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// ============================================
// 7. ANALYTICS & TRACKING
// ============================================

/**
 * Track page visit
 */
function trackPageVisit() {
    const visit = {
        timestamp: new Date().toLocaleString(),
        source: document.referrer || 'direct',
        userAgent: navigator.userAgent
    };
    
    console.log('📊 Page Visit Tracked:', visit);
    
    // In production, send to analytics service
    logAnalyticsEvent('share_page_visit', visit);
}

/**
 * Log analytics event
 */
function logAnalyticsEvent(eventName, eventData) {
    console.log(`📈 Event: ${eventName}`, eventData);
    // In production, send to Google Analytics or similar
}

/**
 * Track referral click
 */
function trackReferralClick(referrerId) {
    const event = {
        eventName: 'referral_click',
        referrerId: referrerId,
        timestamp: new Date().toLocaleString()
    };
    
    console.log('🔗 Referral Tracked:', event);
    logAnalyticsEvent('referral_click', event);
}

// ============================================
// 8. UTILITY FUNCTIONS
// ============================================

/**
 * Get subscriber count
 */
function getSubscriberCount() {
    const subscriptions = loadStoredSubscriptions();
    return subscriptions.length;
}

/**
 * Get subscription stats
 */
function getSubscriptionStats() {
    const subscriptions = loadStoredSubscriptions();
    return {
        total: subscriptions.length,
        today: subscriptions.filter(s => {
            const subDate = new Date(s.subscribedDate);
            const today = new Date();
            return subDate.toDateString() === today.toDateString();
        }).length,
        discountCodesIssued: subscriptions.length,
        averagePerDay: (subscriptions.length / Math.ceil((new Date() - new Date(subscriptions[0]?.subscribedDate || new Date())) / (1000 * 60 * 60 * 24)) || 0).toFixed(2)
    };
}

/**
 * Log subscription stats
 */
function logSubscriptionStats() {
    const stats = getSubscriptionStats();
    console.log('📊 Subscription Statistics:', stats);
    console.log(`Total Subscribers: ${stats.total}`);
    console.log(`Subscribed Today: ${stats.today}`);
    console.log(`Discount Codes Issued: ${stats.discountCodesIssued}`);
}

/**
 * Export subscriptions as CSV (for admin)
 */
function exportSubscriptionsAsCSV() {
    const subscriptions = loadStoredSubscriptions();
    
    if (subscriptions.length === 0) {
        showNotification('No subscriptions to export', 'error');
        return;
    }

    let csv = 'ID,Name,Email,Phone,Subscribed Date,Discount Code,Referral Link\n';
    
    subscriptions.forEach(sub => {
        csv += `"${sub.id}","${sub.name}","${sub.email}","${sub.phone}","${sub.subscribedDate}","${sub.discountCode}","${sub.referralLink}"\n`;
    });

    // Create download link
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `solestyle-subscribers-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    
    showNotification('✅ Subscriptions exported as CSV', 'success');
}

/**
 * Clear all subscriptions (Admin only - Add password protection in production)
 */
function clearAllSubscriptions() {
    if (confirm('⚠️ Are you sure you want to delete ALL subscriptions? This cannot be undone!')) {
        localStorage.removeItem('soleStyleSubscriptions');
        showNotification('✅ All subscriptions cleared', 'success');
    }
}

// Add to setupEventListeners() function
document.getElementById('shareStoreBtn')?.addEventListener('click', () => {
    window.location.href = 'share.html';
});